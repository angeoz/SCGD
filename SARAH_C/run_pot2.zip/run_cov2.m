
rng(1, 'twister');

config.l1 = 0;
%config.kappa = 20;

%mu = ones(1, 200)*4;
%A = randn(200, 200);
%[u, s, v] = svd(A);
%s = eye(200);
%s(200, 200) = config.kappa;
%sigma = u*s*u';
%data = mvnrnd(mu, sigma, 2000);
%save('data_cov_4.mat', 'data');
n = 400;
d = 100;
P = unifrnd(0, 1, [n, n]);
P = P + 1e-5;
P = P ./ sum(P, 2);
R = unifrnd(0, 1, [n, n]);
F = unifrnd(0, 1, [n, d]);
data.P = P;
data.R = R;
data.F = F;
%load data_cov_20;

%rng(1);
%minval = compute_min_val(data, config);

config.lr = 1e-3;
config.gamma = 0.95;
config.max_iters = 50; 
config.max_epochs = 100;
config.A = 400;
config.B = 400;
config.C = 400;
config.opt=1;
config.lr = 1e-2;
config.max_epochs = 1000;
%[resu, grad_resu, norm_resu, ~] = opt_RL(data, config);
%mm = min(resu);
config.beta = 0.9;
config.max_epochs = 200;
config.A = 5;
config.B = 5;
config.C = 1;
config.opt = 3;
config.lr = 1e-2;
[scgd, grad_scgd, norm_scgd, norm_sc] = opt_RL(data, config);
config.opt = 1;
config.lr = 1e-1;
[svrg, grad_svrg, norm_svrg,norm_sv] = opt_RL(data, config);
config.opt = 2;
config.dec = 0;
config.lr = 1e-1;
[spider, grad_spider, norm_spider, norm_sa] = opt_RL(data, config);
subplot(1, 2, 1);
semilogy(grad_scgd, smooth(scgd-mm, 10), '--', grad_svrg, smooth(svrg - mm, 10), 'b', grad_spider, smooth(spider - mm, 10), 'r');
legend('SCGD','VRSC-PG', 'SARAH-C');
xlabel('Grads Calculation');
ylabel('Objective Value Gap');
title('Objective Value Gap vs. Grads Calculation')

subplot(1, 2, 2);
semilogy(grad_scgd, smooth(norm_scgd,10), '--', grad_svrg, smooth(norm_svrg, 10), '-Vb', grad_spider, smooth(norm_spider, 10), '-or');
legend('SCGD','VRSC-PG','SARAH-C');
xlabel('Grads Calculation');
ylabel('Gradient Norm');
title('Gradient Norm vs. Grads Calculation')
%plot(grad_svrg, svrg, 'b', grad_spider,spider, 'r', grad_scgd, scgd, 'g');
%legend('Svrg', 'Spider-A', 'SCGD');
%xlabel('Num Iter');
%ylabel('Objective Value');
%title('Best tuned lrscgd=1e-3, lrsvrg=5e-3, lrspider=1e-2, iters=50, A=10, B=10, eps=1e-2, *10*0.8^{epoch}')
