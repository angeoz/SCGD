function [resu_obj, resu_grad, resu_norm, resu_snorm] = opt_RL(data, config)
%   Detailed explanation goes here
lr = config.lr;
max_epochs = config.max_epochs;
max_iters = config.max_iters;

w = zeros(1, size(data.F,2));
w_t = w;
timer = 0;
eps = 1e-2;
n = 1e1;
fprintf('iter,  obj, l2_grad,  timer f\n');
resu_obj = zeros(1,max_epochs);
grad_cal = 0;
resu_grad = zeros(1, max_epochs);
resu_norm = zeros(1, max_epochs);
resu_snorm = zeros(1, max_epochs * max_iters);
for epoch = 1:max_epochs
	tic;
	w_t = w;
	[G_t, G_dev_t,F_dev_t, full_grad] = GD(data, w_t, config);
    G_0 = zeros(size(G_t,1), size(G_t,2));
    resu_norm(epoch) = norm(full_grad);
    grad_cal = grad_cal + 400*3;
	for iter = 1:max_iters
        if config.opt == 2
            [w, G_t, G_dev_t, w_t, F_dev_t, full_grad, v] = SPIDER(data, w, G_t, G_dev_t, w_t, F_dev_t, config);
            grad_cal = grad_cal + 2 * config.A + 2 * config.B + 2;
            %w = w - lr * v';
            if config.dec == 1
                w = w - lr * power(0.999, epoch) * v';
            else
                w = w - lr * v';
            end
            resu_snorm((epoch-1)*max_iters + iter) = norm(v);
            %if norm(v) < eps
            %    cur_timer = toc;
            %    timer = timer + cur_timer;
            %    [obj, l2] = compute_obj(data,w,config);
            %    resu_obj(epoch) = obj;
            %    resu_grad(epoch) = grad_cal;
            %    eps = 0.5 * eps;
            %    break;
            %end            
        elseif config.opt == 1
            v = SVRG(data, w, G_t, G_dev_t, w_t, full_grad, config);
            grad_cal = grad_cal + 2 * config.A + 2 * config.B + 2;
            w = w - lr * v';
            resu_snorm((epoch-1)*max_iters + iter) = norm(v);
        else
            [G_0, v] = SCGD(data, w, G_0, config);
            grad_cal = grad_cal + config.A + config.B + 1;
            w = w - lr*v';
            resu_snorm((epoch-1)*max_iters + iter) = norm(v);
        end
        %w = w - min(eps/norm(v), 0.5) * v;
		if config.l1 ~= 0
			w = sign(w).* max(0, abs(w)-lr*config.l1);
		end
	end
	cur_timer = toc;
	timer = timer + cur_timer;
	[obj, l2] = compute_obj(data,w,config);
    resu_obj(epoch) = obj;
    resu_grad(epoch) = grad_cal;
    resu_norm(epoch) = norm(v);
	fprintf('%d    %.10f   %.10f   %f\n', epoch, obj, l2, timer);
end

end
%dataF: Feature Matrix of States; n*d
%dataR: Reward Function;n*n
%dataP: Transition Matrix;n*n

%config.A, config.B, config.C
function [w, G_t, G_dev_t, w_t, F_dev_t, full_grad, out] = SPIDER(data, w, G_t, G_dev_t, w_t, F_dev_t, config)
    dataF = data.F;
    dataP = data.P;
    dataR = data.R;
    n = size(dataF, 1);
    d = size(dataF, 2);
    G = G_t;
    indexes = randperm(n);
    indexes = indexes(1:config.A); 
    %% compute G
    G_1 = dataF(:,:) * w';
    G_2 = sum(dataP(:, indexes).* (dataR(:, indexes) + config.gamma * (dataF(indexes, :) * w')'), 2)./sum(dataP(:, indexes), 2);
    G_ = zeros(1, 2*n);
    G_(1:2:end) = G_1;
    G_(2:2:end) = G_2;
    
    G_1_t = dataF(:,:) * w_t';
    G_2_t = sum(dataP(:, indexes).* (dataR(:, indexes) + config.gamma * (dataF(indexes, :) * w_t')'), 2)./sum(dataP(:, indexes), 2);
    G_i_t = zeros(1, 2*n);
    G_i_t(1:2:end) = G_1_t;
    G_i_t(2:2:end) = G_2_t;
    
    G = G - (G_i_t - G_);

    %% compute G'
    
    G_dev = G_dev_t;
    indexes = randperm(n);
    indexes = indexes(1:config.B);
    
    G_dev_1 = dataF';
    G_dev_2 = (dataP(:, indexes) * config.gamma * dataF(indexes, :)./sum(dataP(:, indexes), 2))';
    G_dev_ = zeros(d, 2*n);
    G_dev_(:, 1:2:end) = G_dev_1;
    G_dev_(:, 2:2:end) = G_dev_2;

    G_dev_1_t = dataF';
    G_dev_2_t = (dataP(:, indexes) * config.gamma * dataF(indexes, :)./sum(dataP(:, indexes), 2))';
    G_dev_i_t = zeros(d, 2*n);
    G_dev_i_t(:, 1:2:end) = G_dev_1_t;
    G_dev_i_t(:, 2:2:end) = G_dev_2_t;

    G_dev = G_dev - (G_dev_i_t - G_dev_);

    %% Compute F'
    F_dev = F_dev_t;
    indexes = randperm(n);
    indexes = indexes(1:config.C);
    indexes1 = 2 * indexes - 1;
    indexes2 = 2* indexes;
    indexes = [indexes1, indexes2];
    
    mid = 2 * (G(1:2:end) - G(2:2:end));
    F_dev_ = zeros(2*n, 1);
    F_dev_(1:2:end) = mid;
    F_dev_(2:2:end) = -mid;

    mid_t = 2 * (G_t(1:2:end) - G_t(2:2:end));
    F_dev_i_t = zeros(2*n, 1);
    F_dev_i_t(1:2:end) = mid_t;
    F_dev_i_t(2:2:end) = -mid_t;
    
    F_dev = F_dev - (G_dev_t(:, indexes) * F_dev_i_t(indexes) - G_dev(:, indexes) * F_dev_(indexes))/config.C; 
    
    %% update value: G' * F'
    out = F_dev;
    %% update w_t, G_t, G_dev_t, full_grad
    w_t = w;
    G_t = G;
    G_dev_t = G_dev;
    F_dev_t = F_dev;
    full_grad = out;
end
function [G_t, out]=SCGD(data, w, G_t, config)
    n = size(data.F, 1);
    d = size(data.F, 2);
    dataF = data.F;
    dataP = data.P;
    dataR = data.R;
    G = (1-config.beta) * G_t;
    indexes = randperm(n);
    indexes = indexes(1:config.A);
    %% compute G
    
    G_1 = dataF(:,:) * w';
    G_2 = sum(dataP(:, indexes).* (dataR(:, indexes) + config.gamma * (dataF(indexes, :) * w')'), 2)./sum(dataP(:, indexes), 2);
    G_ = zeros(1, 2*n);
    G_(1:2:end) = G_1;
    G_(2:2:end) = G_2;
    
    G = G + config.beta * G_;
    G = G_;
    %% compute G'
    indexes = randperm(n);
    indexes = indexes(1:config.B);
    
    G_dev_1 = dataF';
    G_dev_2 = (dataP(:, indexes) * config.gamma * dataF(indexes, :)./sum(dataP(:, indexes), 2))';
    G_dev = zeros(d, 2*n);
    G_dev(:, 1:2:end) = G_dev_1;
    G_dev(:, 2:2:end) = G_dev_2;

    %% compute F'
    indexes = randperm(n);
    indexes = indexes(1:config.C);
    indexes1 = 2 * indexes - 1;
    indexes2 = 2* indexes;
    indexes = [indexes1, indexes2];
    
    mid = 2 * (G(1:2:end) - G(2:2:end));
    F_dev_ = zeros(2*n, 1);
    F_dev_(1:2:end) = mid;
    F_dev_(2:2:end) = -mid;
    
    F_dev = G_dev(:, indexes) * F_dev_(indexes)./config.C;
    

	out = F_dev;%vertical
    G_t = G;
end
function out = SVRG(data, w, G_t, G_dev_t, w_t, full_grad, config)
    dataF = data.F;
    dataP = data.P;
    dataR = data.R;
    n = size(dataF, 1);
    d = size(dataF, 2);
    G = G_t;
    indexes = randperm(n);
    indexes = indexes(1:config.A); 
    %% compute G
    G_1 = dataF(:,:) * w';
    G_2 = sum(dataP(:, indexes).* (dataR(:, indexes) + config.gamma * (dataF(indexes, :) * w')'), 2)./sum(dataP(:, indexes), 2);
    G_ = zeros(1, 2*n);
    G_(1:2:end) = G_1;
    G_(2:2:end) = G_2;
    
    G_1_t = dataF(:,:) * w_t';
    G_2_t = sum(dataP(:, indexes).* (dataR(:, indexes) + config.gamma * (dataF(indexes, :) * w_t')'), 2)./sum(dataP(:, indexes), 2);
    G_i_t = zeros(1, 2*n);
    G_i_t(1:2:end) = G_1_t;
    G_i_t(2:2:end) = G_2_t;
    
    G = G - (G_i_t - G_);

    %% compute G'
    
    G_dev = G_dev_t;
    indexes = randperm(n);
    indexes = indexes(1:config.B);
    
    G_dev_1 = dataF';
    G_dev_2 = (dataP(:, indexes) * config.gamma * dataF(indexes, :)./sum(dataP(:, indexes), 2))';
    G_dev_ = zeros(d, 2*n);
    G_dev_(:, 1:2:end) = G_dev_1;
    G_dev_(:, 2:2:end) = G_dev_2;

    G_dev_1_t = dataF';
    G_dev_2_t = (dataP(:, indexes) * config.gamma * dataF(indexes, :)./sum(dataP(:, indexes), 2))';
    G_dev_i_t = zeros(d, 2*n);
    G_dev_i_t(:, 1:2:end) = G_dev_1_t;
    G_dev_i_t(:, 2:2:end) = G_dev_2_t;

    G_dev = G_dev - (G_dev_i_t - G_dev_);

    %% Compute F'
    F_dev = full_grad;
    indexes = randperm(n);
    indexes = indexes(1:config.C);
    indexes1 = 2 * indexes - 1;
    indexes2 = 2* indexes;
    indexes = [indexes1, indexes2];
    
    mid = 2 * (G(1:2:end) - G(2:2:end));
    F_dev_ = zeros(2*n, 1);
    F_dev_(1:2:end) = mid;
    F_dev_(2:2:end) = -mid;

    mid_t = 2 * (G_t(1:2:end) - G_t(2:2:end));
    F_dev_t = zeros(2*n, 1);
    F_dev_t(1:2:end) = mid_t;
    F_dev_t(2:2:end) = -mid_t;
    
    F_dev = F_dev - (G_dev_t(:, indexes) * F_dev_t(indexes) - G_dev(:, indexes) * F_dev_(indexes))./config.C; 
        
    out = F_dev;
end

function [G, G_dev, F_dev, grad] = GD(data, w, config)
    n = size(data.F, 1);
    d = size(data.F, 2);
    dataF = data.F;
    dataP = data.P;
    dataR = data.R;

    %% compute G
    
    G_1 = dataF(:,:) * w';
    G_2 = sum(dataP.* (dataR + config.gamma * (dataF * w')'), 2);
    G = zeros(1, 2*n);
    G(1:2:end) = G_1;
    G(2:2:end) = G_2;
    

    %% compute G'
    G_dev_1 = dataF';
    G_dev_2 = (dataP * config.gamma * dataF)';
    G_dev = zeros(d, 2*n);
    G_dev(:, 1:2:end) = G_dev_1;
    G_dev(:, 2:2:end) = G_dev_2;

    %% compute F'
    mid = 2 * (G(1:2:end) - G(2:2:end));
    F_dev_ = zeros(2*n, 1);
    F_dev_(1:2:end) = mid;
    F_dev_(2:2:end) = -mid;
    
    F_dev = 2 * G_dev * F_dev_./size(F_dev_, 1);
    

	grad = F_dev;%vertical
end
